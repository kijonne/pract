$(document).ready(function () {
    $("#hideAll").click(function () {
        $("p").hide();
    });

    $(".hideButton").click(function () {
        $(this).hide();
    });

    $("#hideFirst").click(function () {
        $("#firstParagraph").hide();
    });

    $("#hideSecond").click(function () {
        $("#secondParagraph").hide();
    });

    $("#hide-test").click(function () {
        $(".test").hide();
    });

    $("#showParagraph").click(function() {
        $("p").show();
    });

    $("#showAll").click(function() {
        $("body *").show();
    });

    $("#fastToggle").click(function() {
        $("#toggleText").toggle();
    });

    $("#slowToggle").click(function() {
        $("#toggleText").toggle(2000);
    });


});
