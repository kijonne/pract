class Cat{
    constructor(name, age, colour) {
        this.name = name;
        this.age = age;
        this.colour = colour;
    }
    meow(){
        console.log("Мяу");
    }
    info(){
        return `Имя: ${this.name}, Возраст: ${this.age}, Окрас: ${this.colour}`;
    }
}
const MyCat = new Cat("Алиса", 5, "рыжий");
MyCat.meow();
console.log(MyCat.info());

function createCat(){
    const name = prompt("Введите имя кота: ");
    const age = prompt("Введите возраст кота: ");
    const colour = prompt("Введите окрас кота: ");
    const userCat = new Cat(name, age, colour);
    console.log(userCat.info());

    return userCat;
}
const createdCat = createCat();

class Tiger extends Cat{
    meow() {
        console.log("ррр");
    }
}

const myTiger = new Tiger("Чипс", 3, "Коричневый");
myTiger.meow();
console.log(myTiger.info());
